﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;
using OpenTK.Input;
using System.Drawing;
using System.IO;



namespace Prong
{
	class Program : GameWindow
	{
		const int PlayerSpeed = 5;
		const int BallSpeed = 3;
		const int BallSize = 20;

		int scorePlayer1 = 0;
		int scorePlayer2 = 0;

		int ballX = 0;
		int ballY = 0;

		int ballSpeedX = BallSpeed;
		int ballSpeedY = BallSpeed;

		int player1Y = 0;
		int player2Y = 0;

		int playerWidth()
		{
			return BallSize;
		}

		int playerHeight()
		{
			return 3 * BallSize;
		}

		int player1X()
		{
			return -ClientSize.Width / 2 + playerWidth() / 2;
		}

		int player2X()
		{
			return ClientSize.Width / 2 - playerWidth() / 2;
		}

		protected override void OnUpdateFrame(FrameEventArgs e)
		{
			ballX += ballSpeedX;
			ballY += ballSpeedY;

			if (ballX + BallSize / 2 > player2X() - playerWidth() / 2 && ballY - BallSize / 2 < player2Y + playerHeight() / 2 && ballY + BallSize / 2 > player2Y - playerHeight() / 2)
			{
				ballSpeedX = -ballSpeedX;
			}

			if (ballX - BallSize / 2 < player1X() + playerWidth() / 2 && ballY - BallSize / 2 < player1Y + playerHeight() / 2 && ballY + BallSize / 2 > player1Y - playerHeight() / 2)
			{
				ballSpeedX = -ballSpeedX;
			}

			if (ballY + BallSize / 2 > ClientSize.Height / 2 || ballY - BallSize / 2 < -ClientSize.Height / 2)
			{
				ballSpeedY = -ballSpeedY;
			}

			if (ballX < -ClientSize.Width / 2 || ballX > ClientSize.Width / 2)
			{
				ballX = 0;
				ballY = 0;
				scorePlayer2++;
			}

			if (Keyboard.GetState().IsKeyDown(Key.W) && player1Y < ClientSize.Height / 2 - playerHeight() / 2)
			{
				player1Y += PlayerSpeed;
			}

			if (Keyboard.GetState().IsKeyDown(Key.S) && player1Y > -ClientSize.Height / 2 + playerHeight() / 2)
			{
				player1Y -= PlayerSpeed;
			}

			if (Keyboard.GetState().IsKeyDown(Key.Up) && player2Y < ClientSize.Height / 2 - playerHeight() / 2)
			{
				player2Y += PlayerSpeed;
			}

			if (Keyboard.GetState().IsKeyDown(Key.Down) && player2Y > -ClientSize.Height / 2 + playerHeight() / 2)
			{
				player2Y -= PlayerSpeed;
			}
		}

		protected override void OnRenderFrame(FrameEventArgs e)
		{
			GL.Viewport(0, 0, ClientSize.Width, ClientSize.Height);

			Matrix4 projection = Matrix4.CreateOrthographic(ClientSize.Width, ClientSize.Height, 0.0f, 1.0f);
			GL.MatrixMode(MatrixMode.Projection);
			GL.LoadMatrix(ref projection);

			GL.Clear(ClearBufferMask.ColorBufferBit);

			DrawRectangle(ballX, ballY, BallSize, BallSize, 0.5f, 0.5f, 0.5f);
			DrawRectangle(player1X(), player1Y, playerWidth(), playerHeight(), 1.0f, 0.0f, 0.0f);
			DrawRectangle(player2X(), player2Y, playerWidth(), playerHeight(), 0.0f, 0.0f, 1.0f);

			SwapBuffers();
		}

		void DrawRectangle(int x, int y, int width, int height, float r, float g, float b)
		{
			GL.Color3(r, g, b);
			GL.Begin(PrimitiveType.Quads);
			GL.Vertex2(-0.5f * width + x, -0.5f * height + y);
			GL.Vertex2(0.5f * width + x, -0.5f * height + y);
			GL.Vertex2(0.5f * width + x, 0.5f * height + y);
			GL.Vertex2(-0.5f * width + x, 0.5f * height + y);
			GL.End();
		}

		static void Main()
		{
			new Program().Run();
		}
	}
}

