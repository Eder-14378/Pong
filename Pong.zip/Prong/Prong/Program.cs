﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System.Drawing;
using System.IO;

namespace Prong
{
	class Program : GameWindow
	{
		const int PlayerSpeed = 5; // Velocidade do jogador
		const int BallSpeed = 3; // Velocidade da bola
		const int BallSize = 20; // Tamanho da bola

		int scorePlayer1 = 0; // Pontuação do jogador 1
		int scorePlayer2 = 0; // Pontuação do jogador 2

		int ballX = 0; // Posição X da bola
		int ballY = 0; // Posição Y da bola

		int ballSpeedX = BallSpeed; // Velocidade X da bola
		int ballSpeedY = BallSpeed; // Velocidade Y da bola

		int player1Y = 0; // Posição Y do jogador 1
		int player2Y = 0; // Posição Y do jogador 2

		int playerWidth()
		{
			return BallSize; // Largura do jogador
		}

		int playerHeight()
		{
			return 3 * BallSize; // Altura do jogador
		}

		int player1X()
		{
			return -ClientSize.Width / 2 + playerWidth() / 2; // Posição X do jogador 1
		}

		int player2X()
		{
			return ClientSize.Width / 2 - playerWidth() / 2; // Posição X do jogador 2
		}

		protected override void OnUpdateFrame(FrameEventArgs e)
		{
			ballX += ballSpeedX;
			ballY += ballSpeedY;

			// Se a bola atingir o jogador 2, inverte a direção X da bola
			if (ballX + BallSize / 2 > player2X() - playerWidth() / 2 && ballY - BallSize / 2 < player2Y + playerHeight() / 2 && ballY + BallSize / 2 > player2Y - playerHeight() / 2)
			{
				ballSpeedX = -ballSpeedX;
			}

			// Se a bola atingir o jogador 1, inverte a direção X da bola
			if (ballX - BallSize / 2 < player1X() + playerWidth() / 2 && ballY - BallSize / 2 < player1Y + playerHeight() / 2 && ballY + BallSize / 2 > player1Y - playerHeight() / 2)
			{
				ballSpeedX = -ballSpeedX;
			}

			// Se a bola atingir o topo ou o fundo, inverte a direção Y da bola
			if (ballY + BallSize / 2 > ClientSize.Height / 2 || ballY - BallSize / 2 < -ClientSize.Height / 2)
			{
				ballSpeedY = -ballSpeedY;
			}

			// Se a bola sair do ecrã, reinicia a bola e incrementa a pontuação do jogador 2
			if (ballX < -ClientSize.Width / 2 || ballX > ClientSize.Width / 2)
			{
				ballX = 0;
				ballY = 0;
				scorePlayer2++;
			}

			// Movimento do jogador 1
			if (Keyboard.GetState().IsKeyDown(Key.W) && player1Y < ClientSize.Height / 2 - playerHeight() / 2)
			{
				player1Y += PlayerSpeed;
			}

			if (Keyboard.GetState().IsKeyDown(Key.S) && player1Y > -ClientSize.Height / 2 + playerHeight() / 2)
			{
				player1Y -= PlayerSpeed;
			}

			// Movimento do jogador 2
			if (Keyboard.GetState().IsKeyDown(Key.Up) && player2Y < ClientSize.Height / 2 - playerHeight() / 2)
			{
				player2Y += PlayerSpeed;
			}

			if (Keyboard.GetState().IsKeyDown(Key.Down) && player2Y > -ClientSize.Height / 2 + playerHeight() / 2)
			{
				player2Y -= PlayerSpeed;
			}
		}

		protected override void OnRenderFrame(FrameEventArgs e)
		{
			GL.Viewport(0, 0, ClientSize.Width, ClientSize.Height);

			Matrix4 projection = Matrix4.CreateOrthographic(ClientSize.Width, ClientSize.Height, 0.0f, 1.0f);
			GL.MatrixMode(MatrixMode.Projection);
			GL.LoadMatrix(ref projection);

			GL.Clear(ClearBufferMask.ColorBufferBit);

			DrawRectangle(ballX, ballY, BallSize, BallSize, 0.5f, 0.5f, 0.5f); // Desenha a bola
			DrawRectangle(player1X(), player1Y, playerWidth(), playerHeight(), 1.0f, 0.0f, 0.0f); // Desenha o jogador 1
			DrawRectangle(player2X(), player2Y, playerWidth(), playerHeight(), 0.0f, 0.0f, 1.0f); // Desenha o jogador 2


			SwapBuffers(); // Troca os buffers
		}

		void DrawRectangle(int x, int y, int width, int height, float r, float g, float b)
		{
			GL.Color3(r, g, b);
			GL.Begin(PrimitiveType.Quads);
			GL.Vertex2(-0.5f * width + x, -0.5f * height + y);
			GL.Vertex2(0.5f * width + x, -0.5f * height + y);
			GL.Vertex2(0.5f * width + x, 0.5f * height + y);
			GL.Vertex2(-0.5f * width + x, 0.5f * height + y);
			GL.End(); 
		}

		static void Main()
		{
			new Program().Run(); // Inicia o jogo
		}
	}
}
